
import React from 'react';
import { IconProps } from '../../types';

export const MusicNoteIcon: React.FC<IconProps> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className || "w-6 h-6"}
  >
    <path d="M12 3v10.55A4.001 4.001 0 0010 20a4 4 0 104-4V7h4V3h-6z" />
  </svg>
);
