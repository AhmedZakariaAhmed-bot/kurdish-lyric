
// Currently no global types needed beyond standard React/DOM types.
// This file is a placeholder for future shared types.

export interface IconProps {
  className?: string;
}
